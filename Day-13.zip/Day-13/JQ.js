function funct1() {
  $("#div2").css("background-color", "red");
  $("#div1,#div3").css("background-color", "yellow");
  $("#p").css("Font-style", "italic");
}
